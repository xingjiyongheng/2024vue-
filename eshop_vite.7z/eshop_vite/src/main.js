import 'vant/lib/index.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'
import Vant from 'vant'

const app = createApp(App)

const pinia = createPinia()

app.use(router)
    .use(Vant)
    .use(pinia)

app.mount('#app')