import { createRouter, createWebHistory } from 'vue-router'
import Home from '@/pages/Home.vue'
import Category from '@/pages/Category.vue'
import Shopcart from '@/pages/Shopcart.vue'
import User from '@/pages/User.vue'
import Login from '@/pages/user/Login.vue'
import Register from '@/pages/user/Register.vue'
import GoodsInfo from '@/pages/goods/GoodsInfo.vue'
import GoodsList from '@/pages/goods/GoodsList.vue'
const routes = [
  { path: '/', name: 'home', redirect: '/home' },
  { path: '/', redirect: '/home', meta: { title: '首页' } },
  { path: '/home', component: Home, name: 'home', meta: { title: '首页' } },
  { path: '/category', component: Category, name: 'category', meta: { title: '分类' } },
  { path: '/shopcart', component: Shopcart, name: 'shopcart', meta: { title: '购物车' } },
  { path: '/user', component: User, name: 'user', meta: { title: '我的' } },
  { path: '/login', component: Login, name: 'login', meta: { title: '登录' } },
  { path: '/register', component: Register, name: 'register', meta: { title: '注册' } },
  { path: '/goodsinfo/:id', component: GoodsInfo, name: 'goodsinfo', props: true, meta: { title: '商品详情' } },
  { path: '/goodslist', component: GoodsList, name: 'goodslist', meta: { title: '商品列表' } },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router