import request from '@/utils/axios'

export function category() {
    return request({
        url: '/category',
        method: 'get'
    })
}

export function getGoodsList() {
    return request({
        url: '/goodslist',
        method: 'get'
    })
}