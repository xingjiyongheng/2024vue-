import request from '@/utils/axios'

export function category() {
    return request({
        url: '/category',
        method: 'get'
    })
}

export function getGoodsList() {
    return request({
        url: '/goodslist',
        method: 'get',
    })
}
//查询商品详细信息，get请求
export function getGoodsInfo(data) {
    return request({
        url: '/goodsinfo',
        method: 'get',
        params: data
    })
}