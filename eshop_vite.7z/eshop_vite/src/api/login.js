import request from '@/utils/axios'
//1. ⽤户登录，post请求，有参数
export function login(data) {
    return request({
        url: '/login',
        method: 'post',
        data: data
    })
}
//2. ⽤户注册，post请求，有参数
export function register(data) {
    return request({
        url: '/register',
        method: 'post',
        data: data
    })
}
//3. 获取⽤户信息，get请求，⽆参，但需要token认证
export function getUserInfo() {
    return request({
        url: '/user',
        method: 'get'
    })
}
export function logout(){
    return request({
        url:'/logout',
        method:'get'
    })
}
export default {
    login,
    register,
    getUserInfo
}