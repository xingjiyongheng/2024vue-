// 引⼊axios
import request from '@/utils/axios'
//1. 获取轮播图⽚,get请求，⽆参数
export function getImgs() {
    return request({
        url: '/imglist',
        method: 'get'
    })
}
//2. 获取商品列表，get请求
export function getGoodsList(data) {
    return request({
        url: '/goodslist',
        method: 'get', data
    })
}
//获取商品分类，get请求
export function category() {
    return request({
        url: '/category',
        method: 'get',
    })
}
//查询商品详细信息，get请求
export function detail(data) {
    return request({
        url: '/goodsinfo',
        method: 'get',
        data
    })
}
//输出三个⽅法
export default {
    getImgs,
    getGoodsList,
    category,
    detail
}