import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
//固定写法，请不要修改，defineStore接收两个参数，第⼀个是store id，第⼆个是创建
//使⽤组合式api，转换如下：
// state ---> 响应式数据
//getters---> computed
//action ---> 函数表达式
//根据vue2⽂档，定义了两个列表，⼀个是购物⻋，⼀个是购买商品
export const useCartStore = defineStore('cart', () => {
    //定义购物⻋
    let cartList = ref([])
    //定义商品购买信息
    let buyList = ref([])
    //加⼊购物⻋，对象格式：{ id: 商品id, count: 购买数量，selected: false 
})
//其中selected表示在购物⻋中的商品是否选中，如果选中，表示购买该商品
//通过selected的设置，统计直接购买商品的数量。
const addCart = (goodsinfo) => {
    var flag = false
    cartList.value.some((item) => {
        if (item.id == goodsinfo.id) {
            item.count += parseInt(goodsinfo.count)
            flag = true
            return true
        }
    })
    if (!flag) {
        cartList.value.push(goodsinfo)
    }
}
//从购物⻋中根据id删除商品
const delCart = (id) => {
    const index = cartList.value.findIndex((item) => {
        if (item.id === id) {
            return true
        }
    })
    cartList.value.splice(index, 1)
}
//设置选中，即设置selected为true
const setCartSelected = (itemid) => {
    const item = cartList.value.find((v) => {
        return v.id == itemid
    })
    item.selected = true
}
//设置未选中
const setCartUnselected = (itemid) => {
    const item = cartList.value.find((v) => {
        return v.id == itemid
    })
    item.selected = false
}
//......
return {
    addCart,
    delCart,
    setCartSelected,
    setCartUnSelected,
}