<template>
  <div>
    <swipe :imgList="imgList"></swipe>
    <submenu :menus="menuList"></submenu>
    <hot-goods :goodsList="goodsList"></hot-goods>
  </div>
</template>
<script setup>
import { onMounted, ref } from 'vue'
import { getImgs, getGoodsList } from '@/api/index.js'
import hotGoods from '@/components/hotgoods.vue'
import swipe from '@/components/swipe.vue';
import submenu from '@/components/submenu.vue'
const goodsList = ref()
const imgList = ref()
const menuList = [
  { name: '新闻资讯', pos: [-96, -121] },
  { name: '图⽚分享', pos: [-312, -121] },
  { name: '商品购买', pos: [-96, -327] },
  { name: '留⾔反馈', pos: [-96, -527] },
  { name: '视频专区', pos: [-312, -732] },
  { name: '联系我们', pos: [-312, -527] }
]
onMounted(async () => {
  const img_list = await getImgs()
  imgList.value = img_list.data
  const goods_list = await getGoodsList()
  goodsList.value = goods_list.data
})
</script>
<style lang="scss" scoped></style>