<template>
  <div>购物⻋</div>
</template>