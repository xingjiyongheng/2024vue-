<template>
  <div>
    <van-row gutter="1">
      <van-col span="6" class="menu-left">
        <van-sidebar v-model="active" @change="onChange">
          <van-sidebar-item :title="item.name" v-for="(item, index) 
  in categoryList" :key="index" />
        </van-sidebar>
      </van-col>
      <van-col span="18" class="menu-right">
        <div ref="rightCategoryDom">
          <div v-for="(item, index) in categoryList" :key="index" class="menu-right-item">
            <div style="font-weight: 600; font-size: 14px">{{
              item.name }}</div>
            <van-grid column-num="3">
              <van-grid-item v-for="(item2, index2) in item.sub" :key="index2">
                <router-link :to="{ name: 'goodslist', params: { category_id: item2.id } }">
                  <img :src="item2.image" alt="" style="width: 70x; height: 70px" />
                  <span style="font-size: 14px; color: #333">{{ item2.name }}</span>
                </router-link>
              </van-grid-item>
            </van-grid>
          </div>
        </div>
      </van-col>
    </van-row>
  </div>
</template>
<script setup>
//引⼊category接⼝
import { category } from '@/api/goods'
import { ref, onMounted, onUnmounted, watch } from 'vue'
//定义active响应式变量
let active = ref(0)
//定义分类列表响应式变量
const categoryList = ref('')
onMounted(async () => {
  //获取商品分类接⼝
  const res = await category()
  //对categroyList进⾏赋值
  categoryList.value = res.data
  console.log(res.data)
})
const onChange = () => {
  console.log(categoryName.value)
}
</script>
<style lang="scss" scoped>
.menu-left {
  position: fixed;
  overflow-y: auto;
}

.menu-right {
  margin-left: 25%;
  overflow-y: scroll;
  height: calc(100vh - 96px);
}
</style>