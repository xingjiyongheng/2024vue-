<template>
  <div>
    <van-tabbar route>
      <van-tabbar-item icon="wap-home-o" replaece to="/home">⾸⻚ </van-tabbar-item>
      <van-tabbar-item icon="apps-o" replaece to="/category">分类 </van-tabbar-item>
      <van-tabbar-item icon="shopping-cart-o" badge="5" replaece to="/shopcart"
        >购物⻋</van-tabbar-item
      >
      <van-tabbar-item icon="setting-o" replaece to="/user">我的</van-tabbar-item>
    </van-tabbar>
  </div>
</template>
    <script setup>
</script>
    <style lang="scss" scoped>
</style>