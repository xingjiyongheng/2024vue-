<template>
  <div>
    <van-nav-bar :title="route.meta.title" :left-text="!isHomePage ? '返回' : ''" :left-arrow="!isHomePage" :style="{
      '--van-nav-bar-background': '#228DFF',
      '--van-nav-bar-icon-color': 'white',
      '--van-nav-bar-title-text-color': 'white',
      '--van-nav-bar-text-color': 'white'
    }" @click-left="onClickLeft"></van-nav-bar>

    <transition name="fade">
      <router-view></router-view>
    </transition>
    <tabbar></tabbar>
  </div>
</template>
<script setup>
import { getImgs } from '@/api/index.js'
import { useRoute } from 'vue-router'
import { computed, onMounted, ref } from 'vue';
import tabbar from '@/components/tabbar.vue'
const route = useRoute()
console.log(route)
const isHomePage = computed(() => {
  return route.path == '/home'
})

const imgList = ref()
onMounted(async () => {
  const res = await getImgs()
  imgList.value = res.data
})
const onClickLeft = () => history.back()
</script>
<style lang="scss">
.fade-enter-from {
  opacity: 0;
  transform: translateX(100%);
}

.fade-leave-to {
  opacity: 0;
  transform: translateX(-100%);
  position: absolute;
}

.fade-enter-active,
.fade-leave-active {
  transition: all 0.5s ease;
}
</style>